# ═══════════════════════════════════════════════════════
# FTP Deploy Script - Aufa Portfolio
# Uploads deploy-v3 folder to aufarafii.id via FTP
# ═══════════════════════════════════════════════════════

param(
    [Parameter(Mandatory=$true)]
    [string]$FtpPassword
)

$ftpServer = "ftp://ftp.aufarafii.id"
$ftpUser = "aufarafi"
$localRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$remoteRoot = "/public_html"

# Files/folders to exclude from upload
$excludeFiles = @("ftp-upload.ps1")

Write-Host ""
Write-Host "═══════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  🚀 FTP Deploy - aufarafii.id" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Server  : ftp.aufarafii.id" -ForegroundColor Gray
Write-Host "  User    : $ftpUser" -ForegroundColor Gray
Write-Host "  Local   : $localRoot" -ForegroundColor Gray
Write-Host "  Remote  : $remoteRoot" -ForegroundColor Gray
Write-Host ""

# Create credential
$secPass = ConvertTo-SecureString $FtpPassword -AsPlainText -Force
$cred = New-Object System.Management.Automation.PSCredential($ftpUser, $secPass)

function Ensure-FtpDirectory($remotePath) {
    try {
        $uri = "$ftpServer$remotePath/"
        $request = [System.Net.FtpWebRequest]::Create($uri)
        $request.Method = [System.Net.WebRequestMethods+Ftp]::MakeDirectory
        $request.Credentials = New-Object System.Net.NetworkCredential($ftpUser, $FtpPassword)
        $request.UseBinary = $true
        $request.UsePassive = $true
        $request.KeepAlive = $false
        $response = $request.GetResponse()
        $response.Close()
        Write-Host "  📁 Created: $remotePath" -ForegroundColor Yellow
    } catch {
        # Directory likely already exists, which is fine
    }
}

function Upload-FtpFile($localFile, $remotePath) {
    try {
        $uri = "$ftpServer$remotePath"
        $request = [System.Net.FtpWebRequest]::Create($uri)
        $request.Method = [System.Net.WebRequestMethods+Ftp]::UploadFile
        $request.Credentials = New-Object System.Net.NetworkCredential($ftpUser, $FtpPassword)
        $request.UseBinary = $true
        $request.UsePassive = $true
        $request.KeepAlive = $false

        $fileContent = [System.IO.File]::ReadAllBytes($localFile)
        $request.ContentLength = $fileContent.Length

        $requestStream = $request.GetRequestStream()
        $requestStream.Write($fileContent, 0, $fileContent.Length)
        $requestStream.Close()

        $response = $request.GetResponse()
        $status = $response.StatusDescription
        $response.Close()

        $fileName = Split-Path $localFile -Leaf
        $sizeKB = [math]::Round($fileContent.Length / 1024, 1)
        Write-Host "  ✅ $remotePath ($sizeKB KB)" -ForegroundColor Green
        return $true
    } catch {
        Write-Host "  ❌ FAILED: $remotePath - $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
}

# Collect all files
$allFiles = Get-ChildItem -Path $localRoot -Recurse -File | Where-Object { $_.Name -notin $excludeFiles }
$totalFiles = $allFiles.Count
$uploadedCount = 0
$failedCount = 0

Write-Host "📦 Found $totalFiles files to upload" -ForegroundColor White
Write-Host "─────────────────────────────────────────" -ForegroundColor DarkGray
Write-Host ""

# Collect and create all directories first
$allDirs = Get-ChildItem -Path $localRoot -Recurse -Directory
foreach ($dir in $allDirs) {
    $relativePath = $dir.FullName.Substring($localRoot.Length).Replace('\', '/')
    $remoteDirPath = "$remoteRoot$relativePath"
    Ensure-FtpDirectory $remoteDirPath
}

Write-Host ""
Write-Host "📤 Uploading files..." -ForegroundColor White
Write-Host ""

# Upload all files
foreach ($file in $allFiles) {
    $relativePath = $file.FullName.Substring($localRoot.Length).Replace('\', '/')
    $remoteFilePath = "$remoteRoot$relativePath"
    
    $result = Upload-FtpFile $file.FullName $remoteFilePath
    if ($result) { $uploadedCount++ } else { $failedCount++ }
}

Write-Host ""
Write-Host "═══════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  📊 Deploy Summary" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  ✅ Uploaded : $uploadedCount files" -ForegroundColor Green
if ($failedCount -gt 0) {
    Write-Host "  ❌ Failed   : $failedCount files" -ForegroundColor Red
}
Write-Host ""
Write-Host "  🌐 Website  : https://aufarafii.id" -ForegroundColor Cyan
Write-Host "  🔒 Admin    : https://aufarafii.id/admin/" -ForegroundColor Cyan
Write-Host ""
